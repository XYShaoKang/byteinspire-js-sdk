'use strict';

const Router = require('koa-router');
const homeController = require('./controllers/home');
const aiController = require('./controllers/v1/ai');

// basic info
const router = new Router();
router.get('/', homeController.getApiInfo);
router.get('/spec', homeController.getSwaggerSpec);

// -------- v1 apis start --------
const v1Router = new Router();

// ai module
const ai = new Router();
ai.post('/translate', aiController.translate);

v1Router.use('/ai', ai.routes(), ai.allowedMethods());

router.use('/v1', v1Router.routes(), v1Router.allowedMethods());
// -------- v1 apis end --------

module.exports = router;
