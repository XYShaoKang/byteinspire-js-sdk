#!/bin/bash

set -e

. /etc/profile

nvm use v10

./node_modules/.bin/pm2 start pm2.config.js --env production --no-daemon