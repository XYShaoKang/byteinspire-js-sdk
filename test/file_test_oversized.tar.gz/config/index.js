'use strict';

const env = process.env.NODE_ENV || 'development';
const configs = {
  base: {
    env,
    consulConfig: {
      host: '10.224.6.170',
      port: 2280,
    },
  },
  production: {
    consulConfig: {},
  },
  development: {},
  test: {},
};
const config = Object.assign(configs.base, configs[env]);

module.exports = config;
