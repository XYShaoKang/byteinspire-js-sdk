'use strict';

const { logger, metrics } = require('@fe/middlewares');

module.exports = (app) => {
  app.use(logger());
  app.use(metrics());
};
