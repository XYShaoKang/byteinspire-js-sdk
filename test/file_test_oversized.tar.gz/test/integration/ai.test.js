'use strict';

const request = require('./reqeust');

describe('AI', () => {
  describe('POST /v1/ai/translate', () => {
    test('<200> should return success with translated text', async () => {
      expect.assertions(3);
      const res = await request
        .post('/v1/ai/translate')
        .send({
          text: '一段要翻译的中文',
          targetLang: 'en',
          srcLang: 'zh',
        })
        .expect('Content-Type', /json/)
        .expect(200);

      const { status, data, message } = res.body;
      const expected = ['translatedText', 'srcText', 'targetLang', 'srcLang'];
      expect(status).toBe('success');
      expect(message).toBe('翻译成功。');
      expect(Object.keys(data)).toEqual(expect.arrayContaining(expected));
    });

    test('<400> should return bad request when missing text or targetLang', async () => {
      expect.assertions(6);
      let res = await request
        .post('/v1/ai/translate')
        .send({
          targetLang: 'en',
          srcLang: 'zh',
        })
        .expect(400);

      let { status, data, message } = res.body;
      expect(status).toBe('fail');
      expect(message).toBe('缺少必要的参数。');
      expect(data).toBeNull();

      res = await request
        .post('/v1/ai/translate')
        .send({
          text: '一段要翻译的中文',
          srcLang: 'zh',
        })
        .expect(400);

      ({ status, data, message } = res.body);
      expect(status).toBe('fail');
      expect(message).toBe('缺少必要的参数。');
      expect(data).toBeNull();
    });
  });
});
