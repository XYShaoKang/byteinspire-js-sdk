'use strict';

const translate = require('../../services/ai/translate');

exports.translate = async (ctx) => {
  const { text, targetLang, srcLang } = ctx.request.body;

  if (!text || !targetLang) {
    return ctx.res.badRequest({
      message: '缺少必要的参数。',
    });
  }

  const data = await translate(text, targetLang, srcLang);
  return ctx.res.ok({
    data,
    message: '翻译成功。',
  });
};
