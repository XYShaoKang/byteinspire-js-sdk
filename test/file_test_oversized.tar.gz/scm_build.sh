#!/bin/bash

set -e

. /etc/profile

# copy files
# rsync -av --exclude output/ --exclude scm_build.sh  . output/

# cd output
chmod +x bootstrap.sh

rm -rf node_modules

nvm use v10

npm set registry http://bnpm.byted.org

npm install --verbose