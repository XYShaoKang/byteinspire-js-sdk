'use strict';

module.exports = {
  apps: [{
    name: 'light_resources',
    script: './bin/www',
    env: {
      NODE_ENV: 'development',
    },
    env_production: {
      NODE_ENV: 'production',
    },
    exec_mode: 'cluster',
    instances: 4,
  }],
};
