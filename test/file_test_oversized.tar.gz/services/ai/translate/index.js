'use strict';

const path = require('path');
const Thrift = require('@byted-service/thrift');

const getAddr = require('../../../utils/consul.js');

const service = Thrift.load(path.join(__dirname, 'index.thrift')).MetaTranslation;

let _client = null;
let _host; let
  _port;

const AI_TRANSLATE_PSM = 'lab.mt.chief';

function getClient(host, port) {
  if (!_client || _host !== host || _port !== port) {
    _client = service.createClient({
      host,
      port,
    });
    _host = host;
    _port = port;
  }
  return _client;
}

module.exports = async function translate(text, targetLang, srcLang) {
  const textList = Array.isArray(text) ? text : [text];
  const addr = await getAddr(AI_TRANSLATE_PSM, {
    cluster: '*',
  });
  const client = getClient(addr.host, addr.port);

  const ping = await client.ping();

  if (ping !== 'pong') {
    throw new Error('Can not connect to translate service. Addr:', addr);
  }

  const res = await client.translation({
    text_list: textList,
    trg_lang: targetLang,
    id: 'test',
    key: '7f30e9315edc6a877b621139f42e3740',
    src_lang: srcLang,
  });

  return res.map(item => ({
    translatedText: item.translated_text,
    srcText: item.text,
    targetLang,
    srcLang,
  }))[0];
};
