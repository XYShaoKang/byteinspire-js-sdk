namespace py MetaTranslationThirft
// TODO:
// some inconsistency between services to be fixed
/* language codes
*  see https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes
* 'af', 'sq', 'am', 'ar', 'hy', 'az', 'eu', 'be', 'bn', 'bs', 'bg', 'ca',  'ny', 'zh', 'co', 'hr',
* 'cs', 'da', 'nl', 'en', 'eo', 'et', 'tl', 'fi', 'fr', 'fy', 'gl', 'ka', 'de', 'el', 'gu', 'ht', 'ha', 'iw',
* 'hi', 'hu', 'is', 'ig', 'id', 'ga', 'it', 'ja', 'jw', 'kn', 'kk', 'km', 'ko', 'ku', 'ky', 'lo', 'la', 'lv',
* 'lt', 'lb', 'mk', 'mg', 'ms', 'ml', 'mt', 'mi', 'mr', 'mn', 'my', 'ne', 'no', 'ps', 'fa', 'pl', 'pt', 'pa', 'ro',
* 'ru', 'sm', 'gd', 'sr', 'st', 'sn', 'sd', 'si', 'sk', 'sl', 'so', 'es', 'su', 'sw', 'sv', 'tg', 'ta', 'te', 'th',
* 'tr', 'uk', 'ur', 'uz', 'vi', 'cy', 'xh', 'yi', 'yo', 'zu'
*/


# batch
typedef list<string> StringList
typedef list<double> DoubleList
typedef list<i32> IntList


// the string in one request should be the same language
struct TranslationRequest{
    1: required StringList text_list;   // should be string list
    2: required string trg_lang;        // must provide
    3: required string id;              // must provide, like p.s.m
    4: required string key;             // must provide, contact zhaoshenjian.01 for the key
    16: optional string src_lang;       // better to provide
    17: optional StringList api_list;   // no need to provide, for test
}

// translation result for each text in text_list of request
struct TranslationResponsePerText{
    1: string translated_text;           // translated string list
    2: string text;                      // original text
    3: string provider;                  // translation provider, lab, cache, google or microsoft
    4: string src_lang;                  // detected src language
    5: double score;                     // the score evaluated
    6: string msg;                       // some msg
    7: i32 code;                         // success (0) or failed (not 0),
}

// translation result for text_list of request
struct TranslationResponse{
    1: StringList translated_text_list;  // translated string list
    2: StringList provider;              // translation provider, lab, cache, google or microsoft
    3: DoubleList score_list;            // the score evaluated
    4: StringList text_list;             // origin text
    5: IntList code;                     // success (0) or failed (not 0),
}

// for better translation
typedef list<TranslationResponse> TranslationResponseList

// for translation
typedef list<TranslationResponsePerText> TranslationResponsePerTextList

service MetaTranslation{
    string ping(),
    TranslationResponsePerTextList translation(1:TranslationRequest req), // use this, cheap and fast

    TranslationResponse faster_translation(1:TranslationRequest req),     // don't use, expensive
    TranslationResponseList better_translation(1:TranslationRequest req), // don't use, expensive
    StringList available_api(1:string src_lang, 2:string trg_lang),       // no need to use, for test
}
