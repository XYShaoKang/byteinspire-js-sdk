'use strict';

const { NOT_FOUND, INVALID_PARAMS, INTERNAL_SERVER_ERROR } = require('./statusCode');

/**
 * Client Failures
 */
module.exports.UNKNOWN_ENDPOINT = {
  statusCode: NOT_FOUND,
  code: 'UNKNOWN_ENDPOINT',
  message: 'The requested endpoint does not exist.',
};

module.exports.INVALID_REQUEST = {
  statusCode: INVALID_PARAMS,
  code: 'INVALID_REQUEST',
  message: 'The request has invalid parameters.',
};


/**
 * Server Errors
 */
module.exports.INTERNAL_ERROR = {
  statusCode: INTERNAL_SERVER_ERROR,
  code: 'INTERNAL_ERROR',
  message: 'The server encountered an internal error.',
};

module.exports.UNKNOWN_ERROR = {
  statusCode: INTERNAL_SERVER_ERROR,
  code: 'UNKNOWN_ERROR',
  message: 'The server encountered an unknown error.',
};
