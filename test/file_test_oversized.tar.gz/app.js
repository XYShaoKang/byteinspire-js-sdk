'use strict';

const Koa = require('koa');
const bodyParser = require('koa-bodyparser');
const cors = require('@koa/cors');
const swagger = require('koa2-swagger-ui');
const registerLogMiddleWare = require('./middlewares/log');
const registerResponseMiddleware = require('./middlewares/response');
const router = require('./routes');

const app = new Koa();

// Set middlewares
registerLogMiddleWare(app);

app.use(
  bodyParser({
    enableTypes: ['json', 'form'],
    formLimit: '10mb',
    jsonLimit: '10mb',
  }),
);
app.use(
  cors({
    origin: true,
  }),
);

app.use(
  swagger({
    routePrefix: '/swagger',
    swaggerOptions: {
      url: '/spec',
    },
  }),
);

registerResponseMiddleware(app);

// Bootstrap application router
app.use(router.routes());
app.use(router.allowedMethods());

// Expose app
module.exports = app;
