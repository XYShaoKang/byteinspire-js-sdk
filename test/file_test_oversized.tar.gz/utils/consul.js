'use strict';

const Consul = require('@byted-service/consul');
const { consulConfig } = require('../config');

const cache = new Map();
const updater = new Consul.Updater();

updater.watch(cache);

Consul.setCache(cache);

const consul = new Consul(consulConfig);

module.exports = async function getAddr(psm, options = {}) {
  const randomAddress = await consul.random(psm, options);
  return randomAddress;
};
