APP_TYPE = "binary"
PRODUCT = "toutiao"
SUBSYS = "developer"
MODULE = "light_resource"

# Please Don't modify the belowing contents unless you know what you are doing.

APPEXECRELOAD = "./node_modules/.bin/pm2 restart pm2.config.js --env production --no-daemon"
APPEXECSTOP = "./node_modules/.bin/pm2 delete pm2.config.js"
